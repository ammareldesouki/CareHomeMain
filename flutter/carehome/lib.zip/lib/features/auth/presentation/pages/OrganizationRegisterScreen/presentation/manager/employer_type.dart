
enum EmployerType {
  individual,
  multiple,
}