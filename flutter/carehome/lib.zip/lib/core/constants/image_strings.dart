/* -- App Image Strings -- */

/// This class contains all the App Images in String formats.
class TImages {
  // -- App Images

  static const String SplashScreen = "assets/images/SplashScreen.png";
  static const String logoImage = "assets/icons/app_logo.png";
  static const String logoRemove = "assets/icons/app_logo-removed.png";

  static const String forgetPassword = "assets/images/forgotpassword.png";




  static const String homeIcon = "assets/icons/homeIcon.png";
  static const String profileIcon = "assets/icons/profileIcon.png";
  static const String mycourses = "assets/icons/mycoursesIcon.png";
  static const String courses= "assets/icons/coursesIcon.png";

  static const String expoloreIcon = "assets/icons/explore.png";
}
